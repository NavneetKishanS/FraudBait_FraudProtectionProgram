﻿using System;
using System.IO;
using System.Linq;

namespace JobAdvertisementFraudPrevention
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Job Advertisement Fraud Prevention!");

            // Load fraud keywords from a file
            string[] fraudKeywords = LoadFraudKeywordsFromFile("Reference.txt");

            while (true)
            {
                Console.WriteLine("\nEnter a job advertisement (or 'exit' to quit):");
                string input = Console.ReadLine();

                if (input.ToLower() == "exit")
                    break;

                bool isFraudulent = DetectFraudulentAdvertisement(input, fraudKeywords);
                Console.WriteLine("Result: " + (isFraudulent ? "Fraudulent advertisement detected!" : "No fraudulent advertisement detected."));
            }

            Console.WriteLine("\nThank you for using Job Advertisement Fraud Prevention. Goodbye!");
        }

        static bool DetectFraudulentAdvertisement(string advertisement, string[] fraudKeywords)
        {
            // Example fraud detection logic
            // You can customize this method with your own fraud detection algorithms

            foreach (string keyword in fraudKeywords)
            {
                if (advertisement.ToLower().Contains(keyword.ToLower()))
                    return true;
            }

            // Check for unrealistic claims
            if (advertisement.Contains("salary: $1,000,000"))
                return true;

            // Check for excessive grammatical or spelling errors
            int errorCount = CountErrors(advertisement);
            if (errorCount > 5)
                return true;

            return false;
        }

        static int CountErrors(string text)
        {
            // Example error counting logic
            // You can customize this method with your own error counting algorithms

            int errorCount = 0;
            // Assume error detection logic goes here

            return errorCount;
        }

        static string[] LoadFraudKeywordsFromFile(string filePath)
        {
            string[] fraudKeywords = null;

            try
            {
                fraudKeywords = File.ReadAllLines(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading fraud keywords file: " + ex.Message);
            }

            return fraudKeywords;
        }
    }
}
