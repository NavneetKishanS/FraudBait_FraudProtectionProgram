﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FakeMessageDetector
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Sample message inputs
           string smsMessage = "Hello! Click this link to win a free vacation: http://www.fakewebsite.com";
           string whatsappMessage = "Hey, have you seen this amazing offer? Check it out at http://www.genuinewebsite.com";
           string instagramMessage = "New post! Check out the link in my bio: http://www.fakewebsite.com";
            //Console.WriteLine("Enter the sms message: ");
            //string smsMessage = Console.ReadLine();
          //  Console.WriteLine("Enter the whatsapp message :");
            //string whatsappMessage = Console.ReadLine();
            //Console.WriteLine("Enter the Instagram message: ");
            //string instagramMessage = Console.ReadLine();

            // Detect fake messages
            bool isSmsFake = DetectFakeMessage(smsMessage, MessageType.SMS);
            bool isWhatsAppFake = DetectFakeMessage(whatsappMessage, MessageType.WhatsApp);
            bool isInstagramFake = DetectFakeMessage(instagramMessage, MessageType.Instagram);

            // Check URL legitimacy
            bool isLinkLegit = await CheckUrlLegitimacy("http://www.genuinewebsite.com");

            // Print results
            Console.WriteLine("\nFake Message Detection Results:");
            Console.WriteLine($"SMS: {isSmsFake}");
            Console.WriteLine($"WhatsApp: {isWhatsAppFake}");
            Console.WriteLine($"Instagram: {isInstagramFake}");
            Console.WriteLine($"URL Legitimacy: {isLinkLegit}\n");

            // Perform both operations for all message types
            await PerformOperationsForMessageType(smsMessage, MessageType.SMS);
            await PerformOperationsForMessageType(whatsappMessage, MessageType.WhatsApp);
            await PerformOperationsForMessageType(instagramMessage, MessageType.Instagram);
        }

        static bool DetectFakeMessage(string message, MessageType messageType)
        {
            // Perform message analysis using machine learning algorithms or other techniques
            // Placeholder logic for demonstration purposes
            List<string> fakeKeywords = new List<string> { "win", "free", "offer", "check out" };

            foreach (string keyword in fakeKeywords)
            {
                if (message.Contains(keyword))
                {
                    Console.WriteLine($"\nFake keyword detected in {messageType}: {keyword}");
                    return true;
                }
            }

            return false;
        }

        static async Task<bool> CheckUrlLegitimacy(string url)
        {
            try
            {
                // Check URL legitimacy using additional techniques and data sources
                using (var httpClient = new HttpClient())
                {
                    // Make a request to an API or perform web scraping to gather information about the URL
                    HttpResponseMessage response = await httpClient.GetAsync(url);

                    // Check the response status code and other relevant factors
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        // Additional checks like content analysis, reputation lookup, etc., can be performed here
                        // Placeholder logic for demonstration purposes
                        string responseBody = await response.Content.ReadAsStringAsync();
                        if (responseBody.Contains("legitimate.com"))
                        {
                            Console.WriteLine("URL is legitimate.");
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"URL legitimacy check failed: {ex.Message}");
            }

            Console.WriteLine("URL is not legitimate.");
            return false;
        }

        static async Task PerformOperationsForMessageType(string message, MessageType messageType)
        {
            Console.WriteLine($"Performing operations for {messageType}:");

            bool isFake = DetectFakeMessage(message, messageType);
            Console.WriteLine($"Is fake message: {isFake}");

            bool isLinkLegit = await CheckUrlLegitimacy(message);
            Console.WriteLine($"Is link legitimate: {isLinkLegit}");

            Console.WriteLine();
        }
    }

    enum MessageType
    {
        SMS,
        WhatsApp,
        Instagram
    }
}
